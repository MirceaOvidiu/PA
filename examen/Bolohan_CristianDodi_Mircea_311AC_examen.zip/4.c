#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 12
#define INFINITY 9999

struct edge
{
    int weight;
    int node1;
    int node2;
    struct edge *next;
};

struct node
{
    int vertex;
    int weight;
    int parent;
    struct node *next;
};

struct Graph
{
    int num_vertices;
    struct node **adj_lists;
};

struct stack
{
    int data;
    struct stack *next;
};

struct queue
{
    int data;
    struct queue *next;
};

void printStatie(int data)
{
    switch(data)
    {
        case 1: printf("Preciziei"); break;
        case 2: printf("Grozavesti"); break;
        case 3: printf("Politehnica"); break;
        case 4: printf("Izvor"); break;
        case 5: printf("Pipera"); break;
        case 6: printf("Eroilor"); break;
        case 7: printf("Piata Unirii"); break;
        case 8: printf("Gara de Nord"); break;
        case 9: printf("Nicolae Grigorescu"); break;
        case 10: printf("Drumul Taberei"); break;
        case 11: printf("Berceni"); break;
        case 12: printf("Universitate"); break;
    }
}

void printMatrix(int matrix[][N])
{
    for(int i = 0; i < N; i++)
    {
        for(int j = 0; j < N; j++)
        {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

void printGraph(struct Graph *graph)
{
    for(int i = 0; i < graph->num_vertices; i++)
    {
        struct node *current = graph->adj_lists[i];
        printStatie(i+1);
        printf(": ");
        while(current != NULL)
        {
            printStatie(current->vertex);
            printf("(%d)", current->weight);
            current = current->next;
            if(current != NULL)
            {
                printf(" -> ");
            }
        }
        printf("\n");
    }
}

void importFromCSV(int matrix[][N])
{
    FILE *f;
    if((f = fopen("statii.csv", "rt")) == NULL)
    {
        printf("Can't open file!");
        exit(1);
    }
    for(int i = 0; i < N; i++)
    {
        int j = 0;
        char row[100];
        char *token;
        fgets(row, 100, f);

        token = strtok(row, ",");
        while(token != NULL)
        {
            matrix[i][j] = atoi(token);
            j++;
            token = strtok(NULL, ",");
        }
    }
    fclose(f);
}

struct node* createNode(int data, int weight)
{
    struct node* new_node = (struct node*)malloc(sizeof(struct node));

    new_node->vertex = data;
    new_node->weight = weight;
    new_node->next = NULL;

    return new_node;
}

struct Graph *createGraph()
{
    struct Graph *graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->num_vertices = N;

    graph->adj_lists = (struct node**)malloc(N * sizeof(struct node*));
    for(int i = 0; i < N; i++)
    {
        graph->adj_lists[i] = NULL;
    }
    return graph;
}  

void addEdge(struct Graph* graph, int src, int dest, int weight)
{
    struct node *new_node = createNode(dest, weight);
    new_node->next = graph->adj_lists[src];
    graph->adj_lists[src] = new_node;
}

int isInList(struct edge *edges, int src, int dest)
{
    struct edge *current = edges;
    while(current != NULL)
    {
        if(current->node1 == dest && current->node2 == src)
        {
            return 1;
        }
        current = current->next;
    }
    return 0;
}

int isInListDijkstra(struct node *head, int data)
{
    struct node *current = head;
    while(current != NULL)
    {
        if(current->vertex == data)
        {
            return 1;
        }
        current = current->next;
    }
    return 0;
}

struct node *nodeList(struct Graph *graph)
{
    struct node *head = NULL;
    for(int i = 0; i < N; i++)
    {
        struct node *adj_list = graph->adj_lists[i];
        while(adj_list != NULL)
        {
            if(!isInListDijkstra(head, adj_list->vertex))
            {
                struct node *current = (struct node*)malloc(sizeof(struct node));
                current->vertex = adj_list->vertex;
                current->weight = INFINITY;
                current->next = head;
                head = current;
            }
            adj_list = adj_list->next;
        }
    }
    return head;
}

void matrixToList(int adj_matrix[][N], struct Graph *graph)
{
    for(int i = 0; i < N; i++)
    {
        for(int j = 0; j < N; j++)
        {
            if(adj_matrix[i][j] != 0)
            {
                addEdge(graph, i, j+1, adj_matrix[i][j]);
            }
        }
    }
}

void ListToMatrix(struct Graph *graph, int matrix[][N])
{
    for(int i = 0; i < N; i++)
    {
        for(int j = 0; j < N; j++)
        {
            matrix[i][j] = 0;
        }
    }
    for(int i = 0; i < N; i++)
    {
        struct node *adj_list = graph->adj_lists[i];
        while(adj_list != NULL)
        {
            matrix[i][adj_list->vertex - 1] = adj_list->weight;
            adj_list = adj_list->next;
        }
    } 
}

void createEdgeList(int matrix[][N], struct edge **edges)
{
    for(int i = 0; i < N; i++)
    {
        for(int j = 0; j < N; j++)
        {
            if(matrix[i][j] != 0 && !isInList(*edges, i+1, j+1))
            {
                struct edge *current = (struct edge*)malloc(sizeof(struct edge));
                current->weight = matrix[i][j];
                current->node1 = i + 1;
                current->node2 = j + 1;
                current->next = *edges;
                *edges = current;
            }
        }
    }
}

void sortList(struct edge **edges)
{
    struct edge *current = *edges;
    while(current != NULL)
        {
            struct edge *next = current->next;  
            while(next != NULL)
                {
                if(current->weight > next->weight) {  
                    int temp_weight = current->weight;  
                    current->weight= next->weight;  
                    next->weight = temp_weight; 

                    int temp_node1 = current->node1;  
                    current->node1 = next->node1;  
                    next->node1 = temp_node1;

                    int temp_node2 = current->node2;  
                    current->node2 = next->node2;  
                    next->node2 = temp_node2;  
                }  
                next = next->next; 
                } 
            
            current = current->next;  
        }
}

void printList(struct edge *edges)
{
    struct edge *current = edges;
    while(current != NULL)
    {
        printf("%d(%d->%d), ", current->weight, current->node1, current->node2);
        current = current->next;
    }
}

//Functions for DFS
int isStackEmpty(struct stack *head)
{
    if(head == NULL)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void push(struct stack **head, int data)
{
    struct stack *current = (struct stack*)malloc(sizeof(struct stack));

    if(isStackEmpty(*head))
    {
        current->data = data;
        current->next = NULL;
        *head = current;
    }
    else
    {
        current->data = data;
        current->next = *head;
        *head = current;
    }
}

void pop(struct stack **head)
{
    struct stack *current;
    if(!isStackEmpty(*head))
    {
        current = *head;
        *head = (*head)->next;
        free(current);
    }
}

int isVisited(struct node *visited, int vertex)
{
    struct node *current = visited;
    while(current != NULL)
    {
        if(current->vertex == vertex)
        {
            return 1;
        }
        current = current->next;
    } 
    return 0;
}

void insertInList(struct node** visited, int data)
{
    struct node *current = *visited;
    struct node *new_node = (struct node*)malloc(sizeof(struct node));
    new_node->vertex = data;
    new_node->next = NULL;
    if(current == NULL)
    {
        current = new_node;
        *visited = current;
    }
    else
    {
        while(current->next != NULL)
        {
            current = current->next;
        }
        current->next = new_node;
    }
}

void insertInListDijkstra(struct node **head, int data, int weight, int parent)
{
    struct node *prev = *head;
    struct node *temp = (struct node*)malloc(sizeof(struct node));
    if(*head == NULL)
    {
        temp->vertex = data;
        temp->weight = weight;
        temp->parent = parent;
        temp->next = *head;
        *head = temp;
    }
    else
    {
        while(prev->next != NULL)
        {
            prev = prev->next;
        }
        temp->vertex = data;
        temp->weight = weight;
        temp->parent = parent;
        temp->next = prev->next;
        prev->next = temp;
    }
}

int DFS(struct Graph *graph, int src, int dest)
{
    struct stack *head = NULL;
    struct node *visited = NULL;
    int visit = src;
    int found = 0;

    insertInList(&visited, visit);
    do
    {
        struct node *adj_list = graph->adj_lists[visit-1];
        int exist_visited_nodes = 1;
        while(adj_list != NULL)
        {
            if(!isVisited(visited, adj_list->vertex))
            {
                if(adj_list->vertex == dest)
                {
                    found = 1;
                    break;
                }
                push(&head, adj_list->vertex);
                insertInList(&visited, adj_list->vertex);
                exist_visited_nodes = 0;
            }
            adj_list = adj_list->next;
        }
        if(exist_visited_nodes)
        {
            pop(&head);
        }
        if(!isStackEmpty(head))
        {
            visit = head->data;
        }
    } while (!isStackEmpty(head));
    return found;
}

void Kruskal(struct Graph *tree, struct edge *edges, int *cost)
{
    FILE *f;
    if((f = fopen("Arbore.csv", "wt")) == NULL)
    {
        printf("Can't open file!");
        exit(1);
    }
    fprintf(f, "Edge Value,Node 1,Node 2\n");

    struct edge *current = edges;
    while(current != NULL)
    {
        if(!DFS(tree, current->node1, current->node2))
        {
            fprintf(f, "%d,%d,%d\n", current->weight, current->node1, current->node2);

            printf("Value %d (", current->weight);
            printStatie(current->node1);
            printf(", ");
            printStatie(current->node2);
            printf(")\n");
            addEdge(tree, current->node1 - 1, current->node2, current->weight);
            addEdge(tree, current->node2 - 1, current->node1, current->weight);
            (*cost) += current->weight;
        }
        current = current->next;
    }
    fprintf(f, "\nCost = %d\n\n", *cost);
    fclose(f);
}

void deleteFromList(struct node **head, int data)
{
    struct node *current = *head;
    if(current->vertex== data)
    {
        *head= current->next;
        free(current);
    }
    
    while(current->next != NULL)
    {
        if(current->next->vertex == data)
        {
            struct node *previous = current;
            struct node *temp = current->next;
            previous->next = temp->next;
            free(temp);
        }
        else
        {
            current = current->next;
        }
        
    }
}

struct node* findInList(struct node *head, int data)
{
    struct node *current = head;
    while(current != NULL)
    {
        if(current->vertex == data)
        {
            return current;
        }
        current = current->next;
    }
    return NULL;
}

struct node *lastElement(struct node *head)
{
    struct node *current = head;
    while(current->next != NULL)
    {
        current = current->next;
    }
    return current;
}

int calculateMin(struct node *head)
{
    int min = INFINITY;
    struct node *current = head;
    while(current != NULL)
    {
        if(min > current->weight)
        {
            min = current->weight;
        }
        current = current->next;
    }
    return min;
}

void Dijkstra(struct Graph *graph, int src, int dest)
{
    int cost = 0;
    struct node *unexplored = nodeList(graph);
    struct node *explored = NULL;
    deleteFromList(&unexplored, src);
    insertInListDijkstra(&explored, src, 0, 0);

    while(unexplored != NULL)
    {
        struct node *current = lastElement(explored);
        struct node *adj_list = graph->adj_lists[current->vertex - 1];
        while(adj_list != NULL)
        {
            struct node *temp = unexplored;
            while(temp != NULL)
            {
                if(temp->vertex == adj_list->vertex)
                {
                    break;
                }
                temp = temp->next;
            }

            if(temp != NULL && temp->weight > current->weight + adj_list->weight)
            {
                temp->weight = current->weight + adj_list->weight;
                temp->parent = current->vertex;
            }
            adj_list = adj_list->next;
        }
        int min = calculateMin(unexplored);
        struct node *temp = unexplored;
        while(temp != NULL)
        {
            if(temp->weight == min)
            {
                insertInListDijkstra(&explored, temp->vertex, temp->weight, temp->parent);
                deleteFromList(&unexplored, temp->vertex);
            }
            temp = temp->next;
        }
    }
    struct node *path = findInList(explored, dest);
    printStatie(path->vertex);
    printf(" -> ");
    while(path->vertex != src)
    {
        printStatie(path->parent);
        path = findInList(explored, path->parent);
        if(path->vertex != src)
        {
            printf(" -> ");
        }
    }
    path = findInList(explored, dest);
    printf("\nCost: %d\n\n", path->weight);
}

int isQueueEmpty(struct queue *front)
{
    if(front == NULL)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void enqueue(struct queue **front, struct queue **rear, int data)
{
    struct queue *current = (struct queue*)malloc(sizeof(struct queue));

    current->data = data;
    current->next = NULL;
    if(isQueueEmpty(*front))
    {
        *front = current;
        *rear = current;
    }
    else
    {
        (*rear)->next = current;
        *rear = current;
    }
}

void dequeue(struct queue **front)
{
    int dequeue_item;
    struct queue *current;
    if(isQueueEmpty(*front))
    {
        printf("Queue is empty\n");
    }
    else
    {
        current = *front;
        dequeue_item = current->data;
        *front = (*front)->next;
        free(current);
    }
}

int main()
{
    int statii[N][N];
    int cost_Kruskal = 0;
    struct Graph *graph  = createGraph();
    struct Graph *tree_Kruskal = createGraph();
    struct edge *edges_Kruskal = NULL;

    importFromCSV(statii);
    matrixToList(statii, graph);

    printf("Matricea de adiacenta a statiilor: \n");
    printMatrix(statii);
    printf("\n");
    printf("Lista de adiacenta a statiilor: \n");
    printGraph(graph);

    //Arborele minim de acoperire
    createEdgeList(statii, &edges_Kruskal);
    sortList(&edges_Kruskal);
    printf("\n");
    printf("Arborele minim de acoperire: \n");
    Kruskal(tree_Kruskal, edges_Kruskal, &cost_Kruskal);
    printf("\n");
    printGraph(tree_Kruskal);
    printf("\ncost = %d\n\n", cost_Kruskal);
    
    //Distanta minima
    int src = 1, dest = 4;
    printf("Drumul minim intre statiile Preciziei si Pipera:\n");
    Dijkstra(graph, src, dest);

    //Timpul total
    struct queue *front = NULL;
    struct queue *rear = NULL;
    long int time = 0;

    //prima data calculam timpul pentru un singur turnichet,
    //daca staudentii ar fi impartiti in mod egal
    for(int i = 0; i < 750; i++)
    {
        //enqueue dureaza 30 sec
        enqueue(&front, &rear, i);
        time += 30;
        //dequeue dureaza 45 sec
        dequeue(&front);
        time += 45;
    }
    time *= 20;
    printf("Timul necesar pentru a trece prin turnicheti toti studentii este:\n");
    printf("%d secunde\n", time);
    printf("%d minute\n", time/60);
    printf("%d ore\n", time/3600);

    return 0;
}